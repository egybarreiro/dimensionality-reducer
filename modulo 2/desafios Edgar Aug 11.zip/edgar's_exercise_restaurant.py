# ============================================================
# ASSIGNMENT: RESTAURANT ORDER SYSTEM
# ============================================================
#
# In this assignment, you will create a simple restaurant
# ordering system using Python.
#
# You will practice:
#
#   - Lists
#   - Dictionaries
#   - for loops
#   - if / else statements
#   - Membership operators: in / not in
#   - Counting values
#   - Updating variables
#
# IMPORTANT:
#
# Do NOT use any external libraries.
#
# Complete each task in order.
#
# ============================================================


# ============================================================
# RESTAURANT MENU
# ============================================================

menu = {
    "burger": 8.50,
    "cheeseburger": 9.50,
    "chicken sandwich": 9.00,
    "grilled chicken": 11.50,
    "pizza": 10.00,
    "tacos": 8.00,
    "burrito": 9.50,
    "quesadilla": 7.50,
    "hot dog": 5.50,
    "salad": 6.50,
    "caesar salad": 7.50,
    "fries": 3.00,
    "onion rings": 4.00,
    "rice": 3.50,
    "beans": 3.00,
    "soup": 5.00,
    "chicken wings": 10.50,
    "mozzarella sticks": 6.00,
    "soda": 2.00,
    "water": 1.50,
    "lemonade": 2.50,
    "coffee": 2.75,
    "iced tea": 2.50,
    "milkshake": 5.00,
    "ice cream": 4.00,
    "cheesecake": 6.50,
    "brownie": 4.50
}


# ============================================================
# CUSTOMER ORDERS
# ============================================================

order_1 = [
    "cheeseburger",
    "fries",
    "soda",
    "cheesecake"
]

order_2 = [
    "grilled chicken",
    "rice",
    "beans",
    "lemonade",
    "brownie"
]

order_3 = [
    "tacos",
    "tacos",
    "quesadilla",
    "soda",
    "soda",
    "ice cream"
]

order_4 = [
    "chicken wings",
    "mozzarella sticks",
    "onion rings",
    "pizza",
    "milkshake"
]

order_5 = [
    "chicken sandwich",
    "caesar salad",
    "water",
    "coffee"
]


# ============================================================
# SELECT AN ORDER
# ============================================================
#
# For Tasks 1 through 7, use order_3.
#
# Store order_3 inside a variable called "order".
#
# Example:
#
# order = ...
#
# ============================================================


# Write your code below:

order = order_3


# ============================================================
# TASK 1: PRINT THE ORDER
# ============================================================
#
# Use a for loop to print every item in the order.
#
# Expected output:
#
# tacos
# tacos
# quesadilla
# soda
# soda
# ice cream
#
# ============================================================


# Write your code below:

for item in order:
    print(item)


# ============================================================
# TASK 2: PRINT ITEMS AND PRICES
# ============================================================
#
# Use the menu dictionary to print each item and its price.
#
# Example:
#
# tacos: $8.00
# tacos: $8.00
# quesadilla: $7.50
# soda: $2.00
# soda: $2.00
# ice cream: $4.00
#
# HINT:
#
# You can get the price using:
#
# menu[item]
#
# ============================================================


# Write your code below:

for item in order:
    price = menu[item]
    print(f"{item}: ${price:.2f}")



# ============================================================
# TASK 3: CALCULATE THE TOTAL
# ============================================================
#
# Calculate the total cost of the order.
#
# Do NOT calculate the answer manually.
#
# Your program should:
#
# 1. Create a variable called total
# 2. Start total at 0
# 3. Use a loop
# 4. Add the price of each item to total
#
# At the end, print the total.
#
# Example:
#
# Total: $31.50
#
# ============================================================


# Write your code below:

total = 0
for item in order:
    total += menu[item]
print(f"Total: ${total:.2f}")



# ============================================================
# TASK 4: COUNT THE NUMBER OF ITEMS
# ============================================================
#
# Print how many items are in the order.
#
# You may use len().
#
# Example:
#
# Number of items: 6
#
# ============================================================


# Write your code below:

for item in order:
    item_count = len(order) 
print(f"Number of items: {item_count}")



# ============================================================
# TASK 5: CHECK FOR A SPECIFIC ITEM
# ============================================================
#
# Check whether the customer ordered "pizza".
#
# Use an if / else statement.
#
# If pizza is in the order, print:
#
# Pizza ordered: Yes
#
# Otherwise print:
#
# Pizza ordered: No
#
# ============================================================


# Write your code below:

if "pizza" in order:
        print("Pizza ordered: Yes")
else:
        print("Pizza ordered: No")


# ============================================================
# TASK 6: COUNT DRINKS
# ============================================================
#
# The following items are drinks:
#
# soda
# water
# lemonade
# coffee
# iced tea
# milkshake
#
# Create this list:
#
# drinks = [
#     "soda",
#     "water",
#     "lemonade",
#     "coffee",
#     "iced tea",
#     "milkshake"
# ]
#
# Count how many drinks are in the customer's order.
#
# HINT:
#
# Create a variable called drink_count.
#
# Start it at:
#
# drink_count = 0
#
# Then loop through the order.
#
# If an item is in the drinks list, increase the count by 1.
#
# Example:
#
# Number of drinks: 2
#
# ============================================================


# Write your code below:

drinks = [
     "soda",
     "water",
     "lemonade",
     "coffee",
     "iced tea",
     "milkshake"
 ]

drink_count = 0

for drink in order:
    if drink in drinks:
        drink_count += 1

        print(f"Number of drinks: {drink_count}")



# ============================================================
# TASK 7: FIND THE MOST EXPENSIVE ITEM
# ============================================================
#
# Find the most expensive item in the order.
#
# Start with:
#
# most_expensive_item = ""
# highest_price = 0
#
# Loop through the order.
#
# Compare each item's price with highest_price.
#
# If the new price is greater:
#
# 1. Update highest_price
# 2. Update most_expensive_item
#
# At the end, print:
#
# Most expensive item: tacos
# Price: $8.00
#
# ============================================================


# Write your code below:

most_expensive_item = ""

highest_price = 0

for item in order:
    price = menu[item]
    if price > highest_price:
        highest_price = price
        most_expensive_item = item

print(f"Price: ${highest_price:.2f}")
print(f"Most expensive item: {most_expensive_item}")




# ============================================================
# TASK 8: CREATE A SIMPLE RECEIPT
# ============================================================
#
# Now combine some of your previous code.
#
# Print a receipt similar to this:
#
#
# ========== RECEIPT ==========
#
# tacos: $8.00
# tacos: $8.00
# quesadilla: $7.50
# soda: $2.00
# soda: $2.00
# ice cream: $4.00
#
# Number of items: 6
# Number of drinks: 2
# Total: $31.50
#
# =============================
#
# You may reuse code from the previous tasks.
#
# ============================================================


# Write your code below:

print("========== RECEIPT ==========")
for item in order:
    price = menu[item]
    print(f"{item}: ${price:.2f}")

item_count = len(order)
print(f"Number of items: {item_count}")

drink_count = 0
for drink in order:
    if drink in drinks:
        drink_count += 1

print(f"Number of drinks: {drink_count}")

total = 0
for item in order:
    total += menu[item]
print(f"Total: ${total:.2f}")
print("=============================")




# ============================================================
# TASK 9: UNAVAILABLE ITEMS
# ============================================================
#
# Sometimes customers may request something that is not
# available on the menu.
#
# Use this order:
#
# test_order = [
#     "burger",
#     "fries",
#     "lobster",
#     "soda",
#     "apple pie"
# ]
#
# Loop through test_order.
#
# BEFORE accessing menu[item], check whether the item exists
# in the menu.
#
# If it exists, print the item and price.
#
# If it does NOT exist, print:
#
# lobster: NOT AVAILABLE
#
# or
#
# apple pie: NOT AVAILABLE
#
#
# HINT:
#
# if item in menu:
#     ...
# else:
#     ...
#
# ============================================================


test_order = [
    "burger",
    "fries",
    "lobster",
    "soda",
    "apple pie"
]


# Write your code below:

for item in test_order:
    if item in menu:
        print(f"{item}: ${menu[item]:.2f}")
    else:
        print(f"{item}: NOT AVAILABLE")

# ============================================================
# TASK 10: COUNT REPEATED ITEMS
# ============================================================
#
# Use order_3 again:
#
# tacos
# tacos
# quesadilla
# soda
# soda
# ice cream
#
# Create an empty dictionary:
#
# item_counts = {}
#
# Your goal is to count how many times each item appears.
#
# Expected result:
#
# tacos: 2
# quesadilla: 1
# soda: 2
# ice cream: 1
#
#
# HINT:
#
# Loop through the order.
#
# Ask:
#
# Is the item already inside item_counts?
#
# If yes:
#     increase its value by 1
#
# If no:
#     add the item to the dictionary with a value of 1
#
# ============================================================


# Write your code below:

item_counts = {}
for item in order:
    if item in item_counts:
        item_counts[item] += 1
    else:
        item_counts[item] = 1

print("Item counts:")
for item, count in item_counts.items():
    print(f"{item}: {count}")


# ============================================================
# CHALLENGE 1: TRY A DIFFERENT ORDER
# ============================================================
#
# Change:
#
# order = order_3
#
# to:
#
# order = order_1
#
# or:
#
# order = order_2
#
# or another order.
#
# Run your program again.
#
# Does your program still work correctly?
#
# Fix any problems you find.
#
# ============================================================
print("==============================")
order = order_1  
print("ORDER 1:")
print("==============================")

# Task 1
for item in order:
    print(item)

# Task 2
for item in order:
    price = menu[item]
    print(f"{item}: ${price:.2f}")

# Task 3
total = 0
for item in order:
    total += menu[item]
print(f"Total: ${total:.2f}")

# Task 4
item_count = len(order)
print(f"Number of items: {item_count}")

# Task 5
if "pizza" in order:
    print("Pizza ordered: Yes")
else:
    print("Pizza ordered: No")

# Task 6
drink_count = 0
for drink in order:
    if drink in drinks:
        drink_count += 1
print(f"Number of drinks: {drink_count}")

# Task 7
most_expensive_item = ""
highest_price = 0
for item in order:
    price = menu[item]
    if price > highest_price:
        highest_price = price
        most_expensive_item = item
print(f"Most expensive item: {most_expensive_item}")
print(f"Price: ${highest_price:.2f}")

# Task 8
print("========== RECEIPT ==========")
for item in order:
    price = menu[item]
    print(f"{item}: ${price:.2f}")

item_count = len(order)
print(f"Number of items: {item_count}")

drink_count = 0
for drink in order:
    if drink in drinks:
        drink_count += 1

print(f"Number of drinks: {drink_count}")

total = 0
for item in order:
    total += menu[item]
print(f"Total: ${total:.2f}")
print("=============================")

# Task 9
for item in test_order:
    if item in menu:
        print(f"{item}: ${menu[item]:.2f}")
    else:
        print(f"{item}: NOT AVAILABLE")

# Task 10
item_counts = {}
for item in order:
    if item in item_counts:
        item_counts[item] += 1
    else:
        item_counts[item] = 1

print("Item counts:")
for item, count in item_counts.items():
    print(f"{item}: {count}")


print("==============================")
order = order_2  
print("ORDER 2:")
print("==============================")

# Task 1
for item in order:
    print(item)

# Task 2
for item in order:
    price = menu[item]
    print(f"{item}: ${price:.2f}")

# Task 3
total = 0
for item in order:
    total += menu[item]
print(f"Total: ${total:.2f}")

# Task 4
item_count = len(order)
print(f"Number of items: {item_count}")

# Task 5
if "pizza" in order:
    print("Pizza ordered: Yes")
else:
    print("Pizza ordered: No")

# Task 6
drink_count = 0
for drink in order:
    if drink in drinks:
        drink_count += 1
print(f"Number of drinks: {drink_count}")

# Task 7
most_expensive_item = ""
highest_price = 0
for item in order:
    price = menu[item]
    if price > highest_price:
        highest_price = price
        most_expensive_item = item
print(f"Most expensive item: {most_expensive_item}")
print(f"Price: ${highest_price:.2f}")

# Task 8
print("========== RECEIPT ==========")
for item in order:
    price = menu[item]
    print(f"{item}: ${price:.2f}")

item_count = len(order)
print(f"Number of items: {item_count}")

drink_count = 0
for drink in order:
    if drink in drinks:
        drink_count += 1

print(f"Number of drinks: {drink_count}")

total = 0
for item in order:
    total += menu[item]
print(f"Total: ${total:.2f}")
print("=============================")

# Task 9
for item in test_order:
    if item in menu:
        print(f"{item}: ${menu[item]:.2f}")
    else:
        print(f"{item}: NOT AVAILABLE")

# Task 10
item_counts = {}
for item in order:
    if item in item_counts:
        item_counts[item] += 1
    else:
        item_counts[item] = 1

print("Item counts:")
for item, count in item_counts.items():
    print(f"{item}: {count}")


# ============================================================
# CHALLENGE 2: PROCESS ALL ORDERS
# ============================================================
#
# Complete this challenge only after finishing the other tasks.
#
# The five customer orders are stored below:
#
# ============================================================

all_orders = [
    order_1,
    order_2,
    order_3,
    order_4,
    order_5
]


# Use a loop to print each order.
#
# Example:
#
# Order 1:
# ['cheeseburger', 'fries', 'soda', 'cheesecake']
#
# Order 2:
# ['grilled chicken', 'rice', 'beans', 'lemonade', 'brownie']
#
# etc.
#
#
# BONUS:
#
# Calculate the total price of each order.
#
# ============================================================


# Write your code below:

# Print each order with its number and calculate the total for each order
grand_total = 0
for i, order in enumerate(all_orders, start=1):
    print(f"Order {i}:")
    print(order)

    order_total = 0
    for item in order:
        if item in menu:
            order_total += menu[item]
        else:
            print(f"Warning: {item} is not in the menu.")

    print(f"Total Order {i}: ${order_total:.2f}\n")
    grand_total += order_total

print("=========================")
print(f"Grand Total (All Orders): ${grand_total:.2f}")


#exercise_restaurant.py
#Displaying exercise_restaurant.py.