""" Implementación de una cola utilizando dos pilas con operaciones 
de enqueue y dequeue. """

class QueueUsingStacks:
    def __init__(self):
        self.stack_in = []
        self.stack_out = []

    def enqueue(self, item):
        # Agregar el elemento a la primera pila
        self.stack_in.append(item)

    def dequeue(self):
        # Si la segunda pila está vacía, transferir elementos de la 
        # primera pila.
        if not self.stack_out:
            while self.stack_in:
                self.stack_out.append(self.stack_in.pop())
        
        # Si la segunda pila sigue vacía, la cola está vacía
        if not self.stack_out:
            raise IndexError("La cola está vacía")
        
        # Devolver el elemento de la segunda pila
        return self.stack_out.pop()

    def is_empty(self):
        return not self.stack_in and not self.stack_out

    def size(self):
        return len(self.stack_in) + len(self.stack_out)
    

# 1 Crear una instancia de la cola
queue = QueueUsingStacks()

# 2 Agregar elementos a la cola
queue.enqueue(1)
queue.enqueue(2)
queue.enqueue(3)

# 3 Eliminar elementos de la cola y mostrar el resultado
print(queue.dequeue())  # Salida: 1
print(queue.dequeue())  # Salida: 2
print(queue.dequeue())  # Salida: 3

