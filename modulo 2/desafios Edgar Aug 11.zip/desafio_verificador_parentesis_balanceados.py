""" Este desafio consiste en implementar una funcion que use una 
pila para veriicar si una expresion tiene parentesis balanceados."""

# Para la entrada "((()))" la salida debe ser True)"
# Para (())) la salida debe ser False

def are_parentheses_balanced(expression):
    stack = []
    for char in expression:
        if char == '(':
            stack.append(char)
        elif char == ')':
            if not stack:
                return False
            stack.pop()
    return len(stack) == 0

input_expression = "((()))"
print(are_parentheses_balanced(input_expression))

input_expression = "(()))"
print(are_parentheses_balanced(input_expression))

