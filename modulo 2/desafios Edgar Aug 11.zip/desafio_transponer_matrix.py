""" Este desafio consiste en crear una funcion para 
transponer una matriz bidimensional."""

matrix = [[1,2,], [3,4], [5,6]]

#La salida transpuesta debe ser [[1, 3, 5], [2, 4, 6]]

def transpose_matrix(matrix):
    return [[matrix[j][i] for j in range(len(matrix))] for i in range(len(matrix[0]))]

print(transpose_matrix(matrix))
