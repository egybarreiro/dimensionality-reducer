""" Este desafio consiste en escribir una funicon para aplanar 
una lista anidada usando comprension de listas."""

nested_list = [[1,2,3], [4,5], [6]]

#salida debe ser [1, 2, 3, 4, 5, 6]

def flatten_list(nested_list):
    return [item for sublist in nested_list for item in sublist]

print(flatten_list(nested_list))
